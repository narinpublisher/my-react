const Engraving = () => {
		return (
				<h1>새기어 놓고서</h1>				
		);
}

export default Engraving;