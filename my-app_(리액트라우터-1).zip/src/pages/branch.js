const Branch = () => {
		return <h1>가지에</h1>;
}

export default Branch;