const Engraving = () => {
		return (
				<h1 className='stylesaqua'>새기어 놓고서</h1>				
		);
}

export default Engraving;