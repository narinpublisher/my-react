const Engraving = () => {
		return <h1 className='stylesaqua'>첫페이지</h1>;
}

export default Engraving;