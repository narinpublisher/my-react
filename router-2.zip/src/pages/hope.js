const Hope = () => {
		return (
			
				<h1 className='styles.red'>희망의 말</h1>
			
		);
};

export default Hope;