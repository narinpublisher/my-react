const Engraving = () => {
		return (
				<h1 className='stylesaqua'>Engraved Within</h1>				
		);
}

export default Engraving;