const Engraving = () => {
		return <h1 className='stylesaqua'>First Page</h1>;
}

export default Engraving;