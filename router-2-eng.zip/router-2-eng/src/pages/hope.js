const Hope = () => {
		return (
			
				<h1 className='styles.red'>Words of Hope</h1>
			
		);
};

export default Hope;