const Branch = () => {
		return <h1>On the Branch</h1>;
}

export default Branch;