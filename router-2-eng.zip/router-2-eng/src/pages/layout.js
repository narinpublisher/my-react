import { Outlet, Link } from "react-router-dom";
import './myStyle.css';

const Layout = () => {
	return (
		<section>
		   <nav>
			<ul id='menu'>
			  <li><Link to='/' onClick= { () => go(0) }>Home</Link></li>
			  <li><Link to='/branch' onClick= { () => go(1) }>On the Branch</Link></li>
			  <li><Link to='/hope' onClick= { () => go(2) }>Words of Hope</Link></li>
			  <li><Link to='/eng' onClick= { () => go(3) }>Engraved Within</Link></li>
			</ul>
		   </nav>
		<Outlet />
		</section>
	);
}
function go ( num ) {	
	console.log ( num );
	let menu = document.querySelectorAll( 'nav li' );
	// Remove previous styles
	for ( let i = 0; i < menu.length; i++ ) {
			menu[i].style.border = 'none';
			menu[i].classList.remove ( 'act' );
	}
	let j;
	let txt;	
	if ( num === 0 ) {
		j = 0; 
		//The background color of the first screen (home.js) becomes transparent.
		txt = 'transparent'; 
	}
	else if ( num === 1 ) {
		j = 1;
		txt = 'gold'; //The background color of branch.js becomes gold
	}
	
	else if ( num === 2 ) {
		 j = 2;
		txt = "yellowgreen"; //The background color of hope.js becomes yellowgreen
	}
	
	else if ( num === 3 ) {
		j = 3;
		txt = "pink";  //eng.js's background color becomes pink
	}
	if ( j !== 0 ) {
		//css for the page moved by clicking
		menu[j].style.border='2px dashed dodgerblue'; 
		menu[j].classList.add('act');
	}
	//Set the background color for the page you move to by clicking
	document.body.style.backgroundColor= txt; 
}
export default Layout;